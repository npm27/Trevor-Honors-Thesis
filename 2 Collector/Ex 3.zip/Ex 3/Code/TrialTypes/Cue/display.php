<div><?php echo $text; ?></div>

<div class="study textcenter">
    <?php echo $cue ?>
</div>

<div class="textcenter">
    <button class="collectorButton collectorAdvance" id="FormSubmitButton">Next</button>
</div>