<?php
    $neededColumns = array('Settings');
    $outputColumns = array('RT', 'Response', 'Accuracy', 'RTfirst', 'RTlast', 'strictAcc', 'lenientAcc', 'Buttons');
