Note: this current file reflects where Collector will be for version 2.0, although the current code base does not yet perfectly match this flowchart document.

This folder contains the file you need to recreate an editable version of the Collector flowchart file.

1.  Go to https://www.draw.io/
2.  Choose where you want to save diagrams to
3.  Open Existing Diagram
4.  Open 'Collector.xml' from the '/FlowChart Files/' folder

To save out your file:
Editable format: File > Export As > 'Draw.io Compressed (.xml)'
Image file:      File > Export As > 'Portable Network Graphics (.png)'
Smallest Image:  File > Export As > 'SVG with embedded (.svg)'